# CG 2022/2023

## Group T08G08

## TP 4 Notes

We accomplished all tasks without any difficulties.

![Screenshot 1](screenshots/cg-t08g08-tp4-1.png)

![Screenshot 2](screenshots/cg-t08g08-tp4-2.png)
