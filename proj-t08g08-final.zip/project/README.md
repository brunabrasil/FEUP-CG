# CG 2022/2023

## Group T08G08

## Project Notes

![Screenshot 1](screenshots/project-t08g08-1.png)

![Screenshot 2](screenshots/project-t08g08-2.png)

![Screenshot 3](screenshots/project-t08g08-3.png)

![Screenshot 4](screenshots/project-t08g08-4.png)

![Screenshot 5](screenshots/project-t08g08-5.png)

Implementamos também a trajetória em parábola do ovo quando é largado pela ave para ser depositado no ninho, mas não é possível tirar foto.

